package us.deathmarine.luyten;

public class FileEntryNotFoundException extends Exception {
	private static final long serialVersionUID = -1019729947179642460L;

}
