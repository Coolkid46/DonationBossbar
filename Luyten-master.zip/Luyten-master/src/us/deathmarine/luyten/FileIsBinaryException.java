package us.deathmarine.luyten;

public class FileIsBinaryException extends Exception {
	private static final long serialVersionUID = -1497200371383232314L;

}
